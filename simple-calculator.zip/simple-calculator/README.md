# Simple Command-Line Calculator

This is a basic C++ calculator that performs four operations: addition, subtraction, multiplication, and division.

## 💻 Features
- Takes two integer inputs from the user
- Accepts an operation (+, -, x, /)
- Performs the operation and outputs the result
- Handles division by zero

## 🧠 Technologies
- C++
- Standard I/O

## 🚀 How to Run
1. Compile the file:
   ```
   g++ calculator.cpp -o calculator
   ```

2. Run the program:
   ```
   ./calculator
   ```

## 📌 Example
```
Enter your first number: 10  
Enter your second number: 5  
Enter an operation (+, -, x, /): x  
Result is: 50
```
